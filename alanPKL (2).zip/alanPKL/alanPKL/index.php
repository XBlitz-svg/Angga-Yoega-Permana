<?php
include "koneksi.php";
$produk = mysqli_query($conn, "SELECT * FROM produk");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>POS Sederhana</title>
    <style>
        body { font-family: Arial, sans-serif; display: flex; background: #f7f7f7; }
        .menu { width: 60%; display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; padding: 20px; }
        .produk { border: 1px solid #ccc; border-radius: 8px; background: #fff; box-shadow: 0 2px 5px rgba(0,0,0,0.1); padding: 5px; text-align: center; cursor: pointer; transition: 0.2s; }
        .produk:hover { transform: scale(1.05); }
        .produk img { width: 100%; height: 100px; object-fit: cover; border-radius: 6px; }
        .kasir { width: 40%; padding: 20px; border-left: 2px solid #000; background: #fff; }
        .bill { min-height: 200px; border: 1px solid #aaa; border-radius: 6px; margin-bottom: 10px; padding: 10px; background: #fafafa; }
        button { margin: 5px; padding: 10px 15px; border: none; border-radius: 6px; cursor: pointer; font-weight: bold; }
        button:hover { opacity: 0.9; }
        .btn-save { background: #3498db; color: white; }
        .btn-print { background: #2ecc71; color: white; }
        .btn-charge { background: #e67e22; color: white; }
        .btn-clear { background: #e74c3c; color: white; }
        .top-bar { width: 100%; position: absolute; top: 10px; left: 10px; }
    </style>
</head>
<body>

<div class="top-bar">
    <a href="produk.php">
        <button>+ Tambah Produk</button>
    </a>
</div>

<div class="menu" style="margin-top:50px;">
    <?php while($row = mysqli_fetch_assoc($produk)) { ?>
        <div class="produk" onclick="tambahProduk('<?php echo $row['nama']; ?>', <?php echo $row['harga']; ?>)">
            <img src="uploads/<?php echo $row['gambar']; ?>" alt="">
            <p><?php echo $row['nama']; ?><br>Rp <?php echo number_format($row['harga']); ?></p>
        </div>
    <?php } ?>
</div>

<div class="kasir">
    <h2>New Customer</h2>
    <div class="bill" id="bill"></div>
    <p><b>Total:</b> Rp <span id="total">0</span></p>
    <button class="btn-save" onclick="saveBill()">Save Bill</button>
    <button class="btn-print" onclick="window.print()">Print Bill</button>
    <button class="btn-charge" onclick="charge()">Charge</button>
    <button class="btn-clear" onclick="clearSale()">Clear Sale</button>
</div>

<script>
    let pesanan = {};
    let total = 0;

    function tambahProduk(nama, harga) {
        if (!pesanan[nama]) {
            pesanan[nama] = { qty: 1, harga: harga };
        } else {
            pesanan[nama].qty++;
        }
        renderBill();
    }

    function renderBill() {
        let billDiv = document.getElementById("bill");
        billDiv.innerHTML = "";
        total = 0;
        for (let nama in pesanan) {
            let item = pesanan[nama];
            let sub = item.qty * item.harga;
            total += sub;
            billDiv.innerHTML += `<p>${nama} x${item.qty} - Rp ${sub.toLocaleString()}</p>`;
        }
        document.getElementById("total").innerText = total.toLocaleString();
    }

    function saveBill() {
        alert("Bill saved!");
    }

    function charge() {
        let bayar = prompt("Masukkan uang pembayaran:");
        if (bayar) {
            let kembali = bayar - total;
            if (kembali >= 0) {
                alert("Total: Rp " + total.toLocaleString() + "\\nBayar: Rp " + bayar + "\\nKembali: Rp " + kembali.toLocaleString());
            } else {
                alert("Uang kurang!");
            }
        }
    }

    function clearSale() {
        if (confirm("Yakin mau hapus semua pesanan?")) {
            pesanan = {};
            total = 0;
            renderBill();
        }
    }
</script>
</body>
</html>
