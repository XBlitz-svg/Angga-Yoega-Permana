<?php
include "koneksi.php";

if (isset($_POST['tambah'])) {
    $nama = $_POST['nama'];
    $harga = $_POST['harga'];

    $gambar = $_FILES['gambar']['name'];
    $tmp = $_FILES['gambar']['tmp_name'];
    move_uploaded_file($tmp, "uploads/".$gambar);

    mysqli_query($conn, "INSERT INTO produk (nama, harga, gambar) VALUES ('$nama','$harga','$gambar')");
    header("Location: index.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Produk</title>
    <style>
        /* ===== CSS inti (menyamakan dengan index.php) ===== */
        body { font-family: Arial, sans-serif; display: flex; background: #f7f7f7; }
        .menu { width: 60%; display: grid; grid-template-columns: repeat(4, 1fr); gap: 10px; padding: 20px; }
        .produk { border: 1px solid #ccc; border-radius: 8px; background: #fff; box-shadow: 0 2px 5px rgba(0,0,0,0.05); padding: 5px; text-align: center; cursor: pointer; transition: 0.2s; }
        .produk:hover { transform: scale(1.05); }
        .produk img { width: 100%; height: 100px; object-fit: cover; border-radius: 6px; }
        .kasir { width: 40%; padding: 20px; border-left: 2px solid #000; background: #fff; }
        .bill { min-height: 200px; border: 1px solid #aaa; border-radius: 6px; margin-bottom: 10px; padding: 10px; background: #fafafa; }
        button { margin: 5px; padding: 10px 15px; border: none; border-radius: 6px; cursor: pointer; font-weight: bold; }
        button:hover { opacity: 0.9; }
        .btn-save { background: #3498db; color: #fff; }
        .btn-print { background: #2ecc71; color: #fff; }
        .btn-charge { background: #e67e22; color: #fff; }
        .btn-clear { background: #e74c3c; color: #fff; }
        .top-bar { width: 100%; position: absolute; top: 10px; left: 10px; }

        /* ===== Tambahan khusus halaman form agar rapi & konsisten ===== */
        body.form-page { display: block; } /* Override display:flex dari index untuk halaman form */
        .form-container {
            width: 100%;
            max-width: 560px;
            background: #ffffff;
            border: 1px solid #e3e3e3;
            border-radius: 10px;
            box-shadow: 0 6px 14px rgba(0,0,0,0.06);
            padding: 22px;
            margin: 60px auto;
        }
        .form-container h2 {
            margin: 0 0 14px;
        }
        .form-group { margin-bottom: 14px; }
        .form-group label {
            display: block;
            font-weight: 600;
            margin-bottom: 6px;
        }
        .form-group input[type="text"],
        .form-group input[type="number"],
        .form-group input[type="file"] {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid #cfcfcf;
            border-radius: 8px;
            outline: none;
            background: #fff;
        }
        .actions {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 10px;
        }
        a.btn-save, a.btn-clear, a.btn-charge, a.btn {
            display: inline-block;
            text-decoration: none;
            padding: 10px 15px;
            border-radius: 6px;
            font-weight: bold;
        }
        a.btn-save:hover, a.btn-clear:hover, a.btn-charge:hover, a.btn:hover { opacity: 0.9; }
    </style>
</head>
<body class="form-page">
    <div class="form-container">
        <h2>Tambah Produk</h2>

        <form method="POST" enctype="multipart/form-data" autocomplete="off">
            <div class="form-group">
                <label for="nama">Nama Produk</label>
                <input type="text" name="nama" id="nama" required>
            </div>

            <div class="form-group">
                <label for="harga">Harga</label>
                <input type="number" name="harga" id="harga" required>
            </div>

            <div class="form-group">
                <label for="gambar">Gambar</label>
                <input type="file" name="gambar" id="gambar" required>
            </div>

            <div class="actions">
                <a href="index.php" class="btn-clear">Batal</a>
                <button type="submit" name="tambah" class="btn-save">Simpan</button>
            </div>
        </form>
    </div>
</body>
</html>
